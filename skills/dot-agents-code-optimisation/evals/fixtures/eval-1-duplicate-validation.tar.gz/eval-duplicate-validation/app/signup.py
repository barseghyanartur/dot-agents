"""User signup flow."""

from app.validators import is_valid_email, is_valid_username


def create_account(username, email):
    if not is_valid_username(username):
        raise ValueError("invalid username")
    if not is_valid_email(email):
        raise ValueError("invalid email")
    return {"username": username, "email": email}
