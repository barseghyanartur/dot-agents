"""Shared input validation helpers."""

import re

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def is_valid_email(email):
    return bool(_EMAIL_RE.match(email))


def is_valid_username(username):
    return 3 <= len(username) <= 30 and username.isalnum()
