"""User profile update flow."""

import re
import json


_EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _check_email(email):
    """Check whether an email address looks valid."""
    return bool(_EMAIL_PATTERN.match(email))


def _check_username(username):
    """Check whether a username is within length and alnum constraints."""
    if len(username) < 3:
        return False
    if len(username) > 30:
        return False
    return username.isalnum()


def _legacy_username_check(username):
    """Old validation path kept temporarily; no longer called anywhere."""
    return username.isalpha()


def update_profile(username, email):
    if not _check_username(username):
        raise ValueError("invalid username")
    if not _check_email(email):
        raise ValueError("invalid email")
    return {"username": username, "email": email}
