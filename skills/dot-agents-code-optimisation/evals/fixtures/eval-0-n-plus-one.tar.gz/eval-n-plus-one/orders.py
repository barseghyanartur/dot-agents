"""Order reporting utilities."""


class Database:
    def get_user(self, user_id):
        """Simulates a network round-trip to fetch a user row."""
        return {"id": user_id, "name": f"user-{user_id}"}

    def get_orders_for_user(self, user_id):
        """Simulates a network round-trip to fetch orders for a user."""
        return [{"id": i, "user_id": user_id, "total": 10.0} for i in range(3)]


def build_report(db, user_ids):
    report = []
    for user_id in user_ids:
        user = db.get_user(user_id)
        orders = db.get_orders_for_user(user_id)
        total = 0
        for order in orders:
            total += order["total"]
        report.append({"user": user["name"], "orders": orders, "total": total})
    return report


def total_spend(db, user_ids):
    """Sum of every order total across every user."""
    grand_total = 0
    for user_id in user_ids:
        orders = db.get_orders_for_user(user_id)
        for order in orders:
            grand_total += order["total"]
    return grand_total


def top_spenders(db, user_ids, limit=5):
    """Return the top-spending users, most expensive first."""
    spends = []
    for user_id in user_ids:
        orders = db.get_orders_for_user(user_id)
        spend = sum(o["total"] for o in orders)
        spends.append((user_id, spend))

    # Selection sort: repeatedly scan the remaining list for the max.
    result = []
    remaining = spends[:]
    while remaining and len(result) < limit:
        best_idx = 0
        for i in range(1, len(remaining)):
            if remaining[i][1] > remaining[best_idx][1]:
                best_idx = i
        result.append(remaining.pop(best_idx))
    return result
